declare @report_id int

SET IDENTITY_INSERT Report ON

INSERT INTO Report
(report_pk , report_nm , report_desc , report_pend_entity_fg, report_mailing_list_fg , report_custom_fg , report_update_corresp_fg , report_handler_class , report_is_count_fg , report_last_update_dt , report_last_update_uid , report_owner_pk , report_category )
VALUES (1, 'Name Count', 'Shows the number of people in each state with a specific first name', 0, 0, 0, 0, "/Reporting/Specialized/NameCountInput.jsp", 0, getdate(), 'admin', 1, 'Membership')

INSERT INTO Report
(report_pk , report_nm , report_desc , report_pend_entity_fg, report_mailing_list_fg , report_custom_fg , report_update_corresp_fg , report_handler_class , report_is_count_fg , report_last_update_dt , report_last_update_uid , report_owner_pk , report_category )
VALUES (2, 'Person Mailing List by Mail Code', 'Generate a mailing list for a specific mailing list code', 0, 1, 0, 0, "/Reporting/Specialized/MailingListInput.jsp", 0, getdate(), 'admin', 1, 'Membership')

INSERT INTO Report
(report_pk , report_nm , report_desc , report_pend_entity_fg, report_mailing_list_fg , report_custom_fg , report_update_corresp_fg , report_handler_class , report_is_count_fg , report_last_update_dt , report_last_update_uid , report_owner_pk , report_category )
VALUES (3, 'Political Rebate Application File', 'Prepare information for printing onto Rebate Applications.', 0, 0, 0, 0, "/Reporting/Specialized/PRBApplicationFileInput.jsp", 0, getdate(), 'admin', 1, 'Membership')

INSERT INTO Report
(report_pk , report_nm , report_desc , report_pend_entity_fg, report_mailing_list_fg , report_custom_fg , report_update_corresp_fg , report_handler_class , report_is_count_fg , report_last_update_dt , report_last_update_uid , report_owner_pk , report_category )
VALUES (4, 'Rebate Check File, Check Register, Final Roster', 'This report provides a listing of the individuals that are getting checks, a listing of the members that have received Rebate checks, and the final listing of the individuals that were given a Rebate for the current rebate year.', 0, 0, 0, 0, "/Reporting/Specialized/RebateCheckFileInput.jsp", 0, getdate(), 'admin', 1, 'Membership')

INSERT INTO Report
(report_pk , report_nm , report_desc , report_pend_entity_fg, report_mailing_list_fg , report_custom_fg , report_update_corresp_fg , report_handler_class , report_is_count_fg , report_last_update_dt , report_last_update_uid , report_owner_pk , report_category )
VALUES (5, 'Preliminary Roster, Rebate Update File', 'This report provides a listing of the individuals that have requested Political Rebates for Membership within the selected Affiliate.', 0, 0, 0, 0, "/preliminaryRosterReport.action", 0, getdate(), 'admin', 1, 'Membership')

INSERT INTO Report
(report_pk , report_nm , report_desc , report_pend_entity_fg, report_mailing_list_fg , report_custom_fg , report_update_corresp_fg , report_handler_class , report_is_count_fg , report_last_update_dt , report_last_update_uid , report_owner_pk , report_category )
VALUES (6, 'Membership Activity', 'Shows membership activity for the current year', 0, 0, 0, 0, "/membershipActivityReport.action", 0, getdate(), 'admin', 1, 'Membership')

INSERT INTO Report
(report_pk , report_nm , report_desc , report_pend_entity_fg, report_mailing_list_fg , report_custom_fg , report_update_corresp_fg , report_handler_class , report_is_count_fg , report_last_update_dt , report_last_update_uid , report_owner_pk , report_category )
VALUES (7, 'Officer Credential Cards', 'Officer Credential Cards', 0, 0, 0, 0, "/officerCredentialCards.action", 0, getdate(), 'admin', 1, 'Membership')

SET IDENTITY_INSERT Report OFF

