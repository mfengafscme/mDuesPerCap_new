declare @parent_pk int
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'I', 'Member ID', 'person_pk', 'Detail', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'S', 'Name', 'full_name', 'Detail', .3)
SET @parent_pk = @@identity
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	('Prefix', 'P', 'V_Person', 'C', 'Prefix', 'prefix_nm', 'Detail', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'S', 'First', 'first_nm', 'Detail', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'S', 'Middle', 'middle_nm', 'Detail', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'S', 'Last', 'last_nm', 'Detail', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	('Suffix', 'P', 'V_Person', 'C', 'Suffix', 'suffix_nm', 'Detail', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
--end children
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'S', 'Alternate Mailing Name', 'alternate_mailing_nm', 'Detail', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'S', 'Nickname', 'nick_nm', 'Detail', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'S', 'Social Security Number', 'ssn', 'Detail', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'B', 'Barred', 'mbr_barred_fg', 'Detail', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'D', 'Expelled Date', 'mbr_expelled_dt', 'Detail', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'S', 'Primary Email', 'primary_email', 'Detail', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'S', 'Alternate Email', 'alternate_email', 'Detail', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'D', 'Date of Birth', 'dob', 'Demographics', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	('Gender', 'P', 'V_Person', 'C', 'Gender', 'gender', 'Demographics', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	('EthnicOrigin', 'P', 'V_Person', 'C', 'Ethnic Origin', 'ethnic_origin', 'Demographics', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	('Religion', 'P', 'V_Person', 'C', 'Religion', 'religion', 'Demographics', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	('MaritalStatus', 'P', 'V_Person', 'C', 'Marital Status', 'marital_status', 'Demographics', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	('Region', 'P', 'V_Person', 'C', 'Region', 'region', 'Demographics', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	('CountryCitizenship', 'P', 'V_Person', 'C', 'Citizenship', 'citizenship', 'Demographics', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'S', 'System Address', 'full_address', 'Address', .3)
SET @parent_pk = @@identity
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'I', 'Address ID', 'paddr_address_id', 'Address', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'S', 'Address1', 'paddr_addr1', 'Address', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'S', 'Address2', 'paddr_addr2', 'Address', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'S', 'City', 'paddr_city', 'Address', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	('State', 'P', 'V_Person', 'C', 'State', 'paddr_state', 'Address', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'I', 'Zip Code', 'paddr_zipcode', 'Address', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'I', 'Zip Plus', 'paddr_zip_plus', 'Address', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
--end children
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'S', 'Carrier Route', 'paddr_carrier_route_info', 'Address', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'S', 'State Description', 'paddr_state_desc', 'Address', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'B', 'Primary', 'paddr_prmry_fg', 'Address', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'B', 'Bad', 'paddr_bad_fg', 'Address', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'B', 'Private', 'paddr_private_fg', 'Address', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'S', 'Phone Number', 'full_Phone', 'Phone', .3)
SET @parent_pk = @@identity
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'I', 'Country Code', 'country_cd', 'Phone', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'S', 'Area Code', 'area_code', 'Phone', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'S', 'Number', 'phone_no', 'Phone', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'P', 'V_Person', 'S', 'Extension', 'phone_extension', 'Phone', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	('PhoneType', 'P', 'V_Person', 'C', 'Type', 'phone_type', 'Phone', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
--end children
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'M', 'V_Member', 'B', 'No Mail', 'no_mail_fg', 'Detail', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'M', 'V_Member', 'D', 'Join Date', 'mbr_join_dt', 'Detail', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'M', 'V_Member', 'D', 'Retired Date', 'mbr_retired_dt', 'Detail', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'M', 'V_Member', 'D', 'Card Sent Date', 'mbr_card_sent_dt', 'Detail', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'M', 'V_Member', 'S', 'Employer Name', 'employer_name', 'Employer', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	('EmployeeJobTitle', 'M', 'V_Member', 'C', 'Job Title', 'emp_job_title', 'Employer', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	('EmployeeSector', 'M', 'V_Member', 'C', 'Sector', 'emp_sector', 'Employer', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	('EmployeeSalaryRange', 'M', 'V_Member', 'C', 'Salary Range', 'emp_salary_range', 'Employer', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'M', 'V_Member', 'I', 'Salary', 'employee_salary', 'Employer', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'M', 'V_Member', 'S', 'Job Site', 'emp_job_site', 'Employer', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	('AFSCMETitle', 'O', 'V_Officer', 'C', 'AFSCME Title', 'title', 'Detail', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'O', 'V_Officer', 'D', 'Position Start Date', 'pos_start_dt', 'Detail', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'O', 'V_Officer', 'D', 'Position End Date', 'pos_end_dt', 'Detail', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'O', 'V_Officer', 'D', 'Position Expiration Date', 'pos_expiration_dt', 'Detail', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'O', 'V_Officer', 'B', 'Steward', 'pos_steward_fg', 'Detail', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'O', 'V_Officer', 'B', 'Suspended', 'suspended_fg', 'Detail', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'O', 'V_Officer', 'S', 'Officer Address', 'full_address', 'Address', .3)
SET @parent_pk = @@identity
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'O', 'V_Officer', 'I', 'Address ID', 'offaddr_address_id', 'Address', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'O', 'V_Officer', 'S', 'Address1', 'offaddr_addr1', 'Address', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'O', 'V_Officer', 'S', 'Address2', 'offaddr_addr2', 'Address', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'O', 'V_Officer', 'S', 'City', 'offaddr_city', 'Address', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	('State', 'P', 'V_Officer', 'C', 'State', 'offaddr_state', 'Address', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'O', 'V_Officer', 'I', 'Zip Code', 'offaddr_zipcode', 'Address', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'O', 'V_Officer', 'I', 'Zip Plus', 'offaddr_zip_plus', 'Address', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
--end children
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'A', 'V_Affiliate', 'S', 'Affiliate Name', 'aff_abbreviated_nm', 'Detail', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'A', 'V_Affiliate', 'S', 'Local / Sub Chapter', 'aff_localSubChapter', 'Detail', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	('AffiliateState', 'A', 'V_Affiliate', 'C', 'State / Nat Type', 'aff_stateNat_type', 'Detail', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'A', 'V_Affiliate', 'S', 'Sub Unit', 'aff_subUnit', 'Detail', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'A', 'V_Affiliate', 'S', 'Council / Retiree Chapter', 'aff_councilRetiree_chap', 'Detail', .3)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'A', 'V_Affiliate', 'S', 'Location Address', 'full_address', 'Address', .3)
SET @parent_pk = @@identity
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'A', 'V_Affiliate', 'I', 'Address ID', 'affaddr_address_id', 'Address', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'A', 'V_Affiliate', 'S', 'Address1', 'affaddr_addr1', 'Address', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'A', 'V_Affiliate', 'S', 'Address2', 'affaddr_addr2', 'Address', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'A', 'V_Affiliate', 'S', 'City', 'affaddr_city', 'Address', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	('State', 'P', 'V_Affiliate', 'C', 'State', 'affaddr_state', 'Address', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'A', 'V_Affiliate', 'I', 'Zip Code', 'affaddr_zipcode', 'Address', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
INSERT INTO [Report_Fields] 
	(com_cd_type_key, field_entity_type, field_table_nm, field_display_type, field_display_name, field_column_name, field_category_name, field_print_width)
	VALUES
	(null, 'A', 'V_Affiliate', 'I', 'Zip Plus', 'affaddr_zip_plus', 'Address', .3)
INSERT INTO [Report_Field_Aggregate] 
	(child_field_pk, parent_field_pk) VALUES(@@identity, @parent_pk)
--end children
