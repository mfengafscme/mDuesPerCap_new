INSERT INTO Privileges VALUES
('MaintainUsers','Maintain Users','G', 0, 'S')
INSERT INTO Privileges VALUES
('MaintainPrivileges','Maintain Privileges','G', 0, 'S')
INSERT INTO Privileges VALUES
('MaintainCodes','Maintain Codes','G', 0, 'S')
INSERT INTO Privileges VALUES
('DataUtilityMemberBasicSearch','Basic','S', 1,'M')
INSERT INTO Privileges VALUES
('VendorMemberSearch','Vendor','S', 0,'M')
INSERT INTO Privileges VALUES
('MaintainQueries','Maintain Queries','G', 0, 'S')
INSERT INTO Privileges VALUES
('GenerateReports','Generate Reports','G', 0, 'S')
INSERT INTO Privileges VALUES
('GenerateMailingList','Generate Mailing List','G', 0, 'S')
INSERT INTO Privileges VALUES
('UploadAffiliateFiles','Upload Affiliate Data','G', 0,'S')
INSERT INTO Privileges VALUES
('UploadInternationalFiles','Upload International Files','G', 0, 'S')
INSERT INTO Privileges VALUES
('MaintainAffiliateDetail','Detail','E', 0,'A')
INSERT INTO Privileges VALUES
('ViewAffiliateDetail','Detail','V', 0,'A')
INSERT INTO Privileges VALUES
('SearchAffiliate','Basic','S', 0,'A')
INSERT INTO Privileges VALUES
('SearchPowerAffiliate','Power','S', 0,'A')
INSERT INTO Privileges VALUES
('ProcessReturnedMail','Process Returned Mail','G', 0, 'S')
INSERT INTO Privileges VALUES
('SearchOrganizations','Basic','S', 0, 'R')
INSERT INTO Privileges VALUES
('MaintainOrganizationDetail','Detail','E', 0, 'R')
INSERT INTO Privileges VALUES
('ViewOrganizationDetail','Detail','V', 0, 'R')
INSERT INTO Privileges VALUES
('MaintainLocationInfo','Locations','E', 0, 'R')
INSERT INTO Privileges VALUES
('ViewLocationInfo','Locations','V', 0, 'R')
INSERT INTO Privileges VALUES
('MaintainMailingListInfo','Mailing List','E', 0, 'S')
INSERT INTO Privileges VALUES
('ViewMaintainMailingListInfo','Mailing List','V', 0, 'S')
INSERT INTO Privileges VALUES
('ViewPersonDetail','Person Detail','V', 0, 'P')
INSERT INTO Privileges VALUES
('MaintainMemberDetail','Detail','E', 0,'M')
INSERT INTO Privileges VALUES
('Maintain12MonthRebateAmount','12 Month Rebate Amount','E', 0, 'S')
INSERT INTO Privileges VALUES
('MaintainPoliticalRebates','Political Rebates','E', 0, 'S')
INSERT INTO Privileges VALUES
('MaintainAddressInfo','Addresses','E', 0, 'P')
INSERT INTO Privileges VALUES
('MaintainAddressSelection','Address Selection','E', 0, 'O')
INSERT INTO Privileges VALUES
('MaintainAffiliateOfficers','Officers','E', 0,'A')
INSERT INTO Privileges VALUES
('MaintainAffiliateOfficerTitles','Officer Titles','E', 0,'A')
INSERT INTO Privileges VALUES
('MaintainAffiliateStaffDetail','Staff','E', 0,'A')
INSERT INTO Privileges VALUES
('MaintainAnnualMemberCardRun','Annual Member Card Run','E', 0,'M')
INSERT INTO Privileges VALUES
('MaintainApplyUpdate','Apply Update','E', 0, 'S')
INSERT INTO Privileges VALUES
('MaintainCharterInfo','Charter','E', 0, 'A')
INSERT INTO Privileges VALUES
('MaintainConstitutionInfo','Constitution','E', 0, 'A')
INSERT INTO Privileges VALUES
('MaintainEmailAddressInfo','Email Address','E', 0, 'P')
INSERT INTO Privileges VALUES
('MaintainEmployerInfo','Employer','E', 0, 'P')
INSERT INTO Privileges VALUES
('MaintainFinancialInfo','Financial','E', 0, 'A')
INSERT INTO Privileges VALUES
('MaintainGeneralDemographicInfo','General Demographics','E', 0, 'S')
INSERT INTO Privileges VALUES
('MaintainLocationSelection','Location Selection','E', 0, 'O')
INSERT INTO Privileges VALUES
('MaintainMemberAffiliateInfo','Member Affiliate','E', 0,'M')
INSERT INTO Privileges VALUES
('MaintainMembershipReportingInfo','Membership Reporting','E', 0,'A')
INSERT INTO Privileges VALUES
('MaintainOfficerDetail','Detail','E', 0,'O')
INSERT INTO Privileges VALUES
('MaintainOrganizationAssociateDetail','Associate','E', 0, 'R')
INSERT INTO Privileges VALUES
('MaintainParticipationDetail','Participation Detail','E', 0, 'M')
INSERT INTO Privileges VALUES
('MaintainParticipationGroups','Participation Groups','E', 0, 'M')
INSERT INTO Privileges VALUES
('MaintainPersonDetail','Person Detail','E', 0, 'P')
INSERT INTO Privileges VALUES
('MaintainPhoneNumberInfo','Phone Numbers','E', 0, 'P')
INSERT INTO Privileges VALUES
('MaintainPoliticalLegislativeInfo','Political Legislative','G', 0, 'P')
INSERT INTO Privileges VALUES
('MaintainPoliticalRebateInfo','Political Rebate','E', 0, 'P')
INSERT INTO Privileges VALUES
('PerformMassChange','Perform Mass Change','G', 0, 'S')
INSERT INTO Privileges VALUES
('SearchApplyUpdateLog','Search Apply Update Log','G', 0, 'S')
INSERT INTO Privileges VALUES
('SearchMember','Basic','S', 0,'M')
INSERT INTO Privileges VALUES
('SearchOfficer','Basic','S', 0,'O')
INSERT INTO Privileges VALUES
('SearchPerson','Person','S', 0, 'P')
INSERT INTO Privileges VALUES
('SearchPowerMember','Power','S', 0,'M')
INSERT INTO Privileges VALUES
('SearchPowerPerson','Power','S', 0, 'P')
INSERT INTO Privileges VALUES
('ViewAddressInformation','Addresses','V', 0, 'P')
INSERT INTO Privileges VALUES
('ViewAddressSelection','Address Selection','V', 0, 'O')
INSERT INTO Privileges VALUES
('ViewAffiliateChangeHistory','Affiliate Change History','V', 0,'A')
INSERT INTO Privileges VALUES
('ViewAffiliateHierarchy','Affiliate Hierarchy','G', 1,'A')
INSERT INTO Privileges VALUES
('ViewAffiliateOfficers','Officers','V', 0,'A')
INSERT INTO Privileges VALUES
('ViewAffiliateOfficerTitles','Officer Titles','V', 0,'A')
INSERT INTO Privileges VALUES
('ViewAffiliateStaffInfo','Staff','V', 0,'A')
INSERT INTO Privileges VALUES
('ViewAnnualMemberCardRun','Annual Member Card Run','V', 0,'M')
INSERT INTO Privileges VALUES
('ViewApplyUpdate','Apply Update','V', 0, 'S')
INSERT INTO Privileges VALUES
('ViewCharterInfo','Charter','V', 0, 'A')
INSERT INTO Privileges VALUES
('ViewCommentHistory','Comment History','V', 0, 'A')
INSERT INTO Privileges VALUES
('ViewConstitutionInfo','Constitution','V', 0, 'A')
INSERT INTO Privileges VALUES
('ViewCorrespondenceHistory','Correspondence History','V', 0, 'P')
INSERT INTO Privileges VALUES
('ViewEmailAddressInfo','Email Address','V', 0, 'P')
INSERT INTO Privileges VALUES
('ViewEmployerInfo','Employer','V', 0, 'M')
INSERT INTO Privileges VALUES
('ViewFinancialInfo','Financial','V', 0, 'A')
INSERT INTO Privileges VALUES
('ViewGeneralDemographicInfo','General Demographics','V', 0, 'M')
INSERT INTO Privileges VALUES
('ViewMemberAffiliateInfo','Member Affiliate','V', 0,'M')
INSERT INTO Privileges VALUES
('ViewMemberDetail','Detail','V', 0,'M')
INSERT INTO Privileges VALUES
('ViewMembershipReportingInfo','Membership Reporting','V', 0,'A')
INSERT INTO Privileges VALUES
('ViewOfficerDetail','Detail','V', 0,'O')
INSERT INTO Privileges VALUES
('ViewOfficerHistory','Officer History','V', 0,'O')
INSERT INTO Privileges VALUES
('ViewOrganizationAssociateInfo','Associate','V', 0, 'R')
INSERT INTO Privileges VALUES
('ViewParticipationDetail','Participation Detail','V', 0, 'M')
INSERT INTO Privileges VALUES
('ViewParticipationGroups','Participation Groups','V', 0, 'M')
INSERT INTO Privileges VALUES
('ViewPhoneNumberInfo','Phone Numbers','V', 0, 'P')
INSERT INTO Privileges VALUES
('ViewPoliticalLegislativeInfo','Political Legislative','V', 0, 'M')
INSERT INTO Privileges VALUES
('ViewPoliticalRebateInfo','Political Rebate','V', 0, 'P')
INSERT INTO Privileges VALUES
('ScheduleNCOAUpdate','Schedule NCOAUpdate','G', 0, 'S')

