if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[V_Officer]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[V_Officer]
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[V_Affiliate]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[V_Affiliate]
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[V_Member]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[V_Member]
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[V_Person]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[V_Person]
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[V_Officer_Address]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[V_Officer_Address]
GO


CREATE VIEW V_Person  AS
SELECT  p.person_pk,
--person detail 

--name 
	prefixes.com_cd_desc as prefix_nm, first_nm, last_nm, middle_nm, suffixes.com_cd_desc as suffix_nm, 
    ISNULL(p.last_nm, '') +
	ISNULL(' ' + suffixes.com_cd_desc, '') +
	ISNULL(',' + ISNULL(prefixes.com_cd_desc, '') + ISNULL(' ' + p.first_nm, '') +	ISNULL(' ' + p.middle_nm, '') , '')
	AS full_name,
    
	alternate_mailing_nm, nick_nm, ssn, mbr_expelled_dt,
	CASE mbr_barred_fg WHEN 0 THEN 'False' WHEN 1 then 'True' ELSE null END as mbr_barred_fg,

--address
	CASE paddr.addr_prmry_fg WHEN 0 THEN 'False' WHEN 1 then 'True' ELSE null END as paddr_prmry_fg,
	CASE paddr.addr_bad_fg WHEN 0 THEN 'False' WHEN 1 then 'True' ELSE null END as paddr_bad_fg,
	CASE paddr.addr_private_fg WHEN 0 THEN 'False' WHEN 1 then 'True' ELSE null END as paddr_private_fg,
	paddr.addr1 as paddr_addr1, paddr.addr2 as paddr_addr2, paddr.city as paddr_city, paddr.state as paddr_state, paddr.zipcode as paddr_zipcode, paddr.zip_plus as paddr_zip_plus,
	ISNULL(paddr.addr1, '') +
	ISNULL(' ' + paddr.addr2, '') +
	ISNULL(' ' + paddr.city + ',', '') +
	ISNULL(' ' + paddr.state, '') +
	ISNULL(' ' + paddr.zipcode, '') + 
	ISNULL('-' + paddr.zip_plus, '')
	AS full_address,
	states.com_cd_desc as paddr_state_desc,
	paddr.carrier_route_info as paddr_carrier_route_info,
	'1' + CONVERT(varchar, paddr.address_pk) as paddr_address_id,
--demographics
	d.dob, genders.com_cd_desc as gender, ethnic_origins.com_cd_desc as ethnic_origin, religions.com_cd_desc as religion, marital_statuses.com_cd_desc as marital_status, regions.com_cd_desc as region, citizenships.com_cd_desc as citizenship,
--phone
	ISNULL(ph.country_cd + ' ', '') +
	ISNULL(ph.area_code + '-', '') +
	ISNULL(ph.phone_no, '') +
	ISNULL(' ' + ph.phone_extension, '')
	AS full_phone,
	ph.area_code, ph.phone_no, ph.country_cd, ph.phone_extension, phone_types.com_cd_desc as phone_type,
--email
	primary_email.person_email_addr as primary_email,
	alternate_email.person_email_addr as alternate_email
FROM	Person p
LEFT OUTER JOIN Person_Demographics d ON d.person_pk = p.person_pk
LEFT OUTER JOIN Person_Phone ph ON ph.person_pk = p.person_pk
LEFT OUTER JOIN Person_Email primary_email ON primary_email.person_pk = p.person_pk AND primary_email.email_type=71001
LEFT OUTER JOIN Person_Email alternate_email ON alternate_email.person_pk = p.person_pk AND alternate_email.email_type=71002
LEFT OUTER JOIN Common_Codes suffixes ON p.suffix_nm = suffixes.com_cd_pk
LEFT OUTER JOIN Common_Codes prefixes ON p.prefix_nm = prefixes.com_cd_pk
LEFT OUTER JOIN Common_Codes phone_types ON ph.phone_type = phone_types.com_cd_pk
LEFT OUTER JOIN Common_Codes genders ON d.gender = genders.com_cd_pk
LEFT OUTER JOIN Common_Codes ethnic_origins ON d.ethnic_origin = ethnic_origins.com_cd_pk
LEFT OUTER JOIN Common_Codes religions ON d.religion = religions.com_cd_pk
LEFT OUTER JOIN Common_Codes marital_statuses ON d.marital_status = marital_statuses.com_cd_pk
LEFT OUTER JOIN Common_Codes regions ON d.region_fk = regions.com_cd_pk
LEFT OUTER JOIN Common_Codes citizenships ON d.citizenship = citizenships.com_cd_pk
LEFT OUTER JOIN Person_SMA s ON p.person_pk = s.person_pk AND s.current_fg=1
INNER JOIN Person_Address paddr ON s.address_pk = paddr.address_pk 
LEFT OUTER JOIN Common_Codes states ON states.com_cd_cd = paddr.state AND states.com_cd_type_key = 'State' 


GO

CREATE VIEW V_Member AS
SELECT
--member
	m.person_pk, 
	m.aff_pk, mbr_join_dt, mbr_retired_dt, mbr_card_sent_dt,
	CASE no_mail_fg WHEN 0 THEN 'False' WHEN 1 then 'True' ELSE null END as no_mail_fg,
--employer
	employer_name,
	emp_job_titles.com_cd_desc as emp_job_title,
	emp_sectors.com_cd_desc as emp_sector,
	emp_salary_ranges.com_cd_desc as emp_salary_range,
	employee_salary,
	emp_job_site
FROM Aff_Members m
LEFT OUTER JOIN Aff_Mbr_Employers emp ON emp.aff_pk = m.aff_pk AND emp.person_pk = m.person_pk
LEFT OUTER JOIN Common_Codes emp_job_titles ON emp.emp_job_title = emp_job_titles.com_cd_pk
LEFT OUTER JOIN Common_Codes emp_sectors ON emp.emp_sector = emp_sectors.com_cd_pk
LEFT OUTER JOIN Common_Codes emp_salary_ranges ON emp.emp_salary_range = emp_salary_ranges.com_cd_pk

GO

create view V_Officer_Address  as
select 
 o.person_pk as offaddr_person_pk,
 addr1 AS offaddr_addr1, 
 addr2 AS offaddr_addr2, 
 city AS offaddr_city,
 state AS offaddr_state,
 zipcode AS offaddr_zipcode,
 zip_plus AS offaddr_zip_plus,
 '1' + CONVERT(varchar, address_pk) as offaddr_address_id
FROM Officer_History o
INNER JOIN Person_Address pa ON o.pos_addr_from_person_pk = pa.address_pk
UNION
select 
 o.person_pk as offaddr_person_pk,
 addr1 AS offaddr_addr1, 
 addr2 AS offaddr_addr2, 
 city AS offaddr_city,
 state AS offaddr_state,
 zipcode AS offaddr_zipcode,
 zip_plus AS offaddr_zip_plus,
 '2' + CONVERT(varchar, org_addr_pk) as offaddr_address_id
FROM Officer_History o
INNER JOIN Org_Address oa ON o.pos_addr_from_org_pk = oa.org_addr_pk

GO

CREATE VIEW V_Officer  AS
SELECT
--officer
 groups.aff_pk, o.person_pk, titles.com_cd_desc AS title, o.pos_start_dt, o.pos_end_dt, o.pos_expiration_dt,
 CASE pos_steward_fg WHEN 0 THEN 'False' WHEN 1 then 'True' ELSE null END as pos_steward_fg,
 CASE suspended_fg WHEN 0 THEN 'False' WHEN 1 then 'True' ELSE null END as suspended_fg,
--address
 '2' + CONVERT(varchar, org_addr_pk) as offaddr_address_id,
 offaddr_addr1,  offaddr_addr2,  offaddr_city, offaddr_state, offaddr_zipcode, offaddr_zip_plus,
 ISNULL(offaddr_addr1, '') +
 ISNULL(' ' + offaddr_addr2, '') +
 ISNULL(' ' + offaddr_city + ',', '') +
 ISNULL(' ' + offaddr_state, '') +
 ISNULL(' ' + offaddr_zipcode, '') +
 ISNULL('-' + offaddr_zip_plus, '')
 as full_address
FROM Officer_History o
LEFT OUTER JOIN V_Officer_Address addr ON addr.offaddr_person_pk = o.person_pk
LEFT OUTER JOIN Org_Address oa ON o.pos_addr_from_org_pk = oa.org_addr_pk
INNER JOIN Aff_Officer_Groups groups ON groups.office_group_id = o.office_group_id AND o.aff_pk = groups.aff_pk
INNER JOIN AFSCME_Offices offices ON o.afscme_office_pk = offices.afscme_office_pk 
INNER JOIN Common_Codes titles ON titles.com_cd_pk = offices.afscme_title_nm

GO

CREATE VIEW V_Affiliate  AS
SELECT aff_pk,
	aff_abbreviated_nm, aff_type, aff_localSubChapter, aff_stateNat_type, aff_subUnit, aff_councilRetiree_chap,
--address
	affaddr.addr1 as affaddr_addr1, affaddr.addr2 as affaddr_addr2, affaddr.city as affaddr_city, affaddr.state as affaddr_state, affaddr.zipcode as affaddr_zipcode, affaddr.zip_plus as affaddr_zip_plus, affaddr.attention_line as affaddr_attention_line,
	'2' + CONVERT(varchar, affaddr.org_addr_pk) as affaddr_address_id,
 ISNULL(affaddr.addr1, '') +
 ISNULL(' ' + affaddr.addr2, '') +
 ISNULL(' ' + affaddr.city + ',', '') +
 ISNULL(' ' + affaddr.state, '') +
 ISNULL(' ' + affaddr.zipcode, '') +
 ISNULL('-' + affaddr.zip_plus, '')
 as full_address
FROM Aff_Organizations a
LEFT OUTER JOIN Org_Locations l ON a.aff_pk = l.org_pk AND location_primary_fg = 1
INNER JOIN Org_Phone p ON p.org_locations_pk = l.org_locations_pk
INNER JOIN Org_Address affaddr ON affaddr.org_locations_pk = l.org_locations_pk

